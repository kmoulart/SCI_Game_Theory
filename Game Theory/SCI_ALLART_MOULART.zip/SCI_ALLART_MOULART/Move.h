//
//  Move.h
//  Game Theory
//
//  Created by Kévin Moulart on 02/12/13.
//  Copyright (c) 2013 Kévin Moulart. All rights reserved.
//

#ifndef Game_Theory_Move_h
#define Game_Theory_Move_h

enum Move
{
    COOP,
    DEFECT
};

#endif
