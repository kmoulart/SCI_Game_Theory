if last_move == None:
	memory = 1
	last_move = 1

if last_move == 0 and memory == 0:
	coop = 0
else:
	coop = 1

memory = last_move