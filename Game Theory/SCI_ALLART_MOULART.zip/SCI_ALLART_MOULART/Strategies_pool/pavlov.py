if memory == None:
	memory = 1
	last_move = 1

if memory == last_move:
	coop = 1
else:
	coop = 0

memory = coop

