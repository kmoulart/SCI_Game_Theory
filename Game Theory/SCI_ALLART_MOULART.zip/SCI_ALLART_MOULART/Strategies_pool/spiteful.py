if memory == None:
	memory = 0

if last_move == 0:
	memory = 1

if memory == 1:
	coop = 0
else:
	coop = 1