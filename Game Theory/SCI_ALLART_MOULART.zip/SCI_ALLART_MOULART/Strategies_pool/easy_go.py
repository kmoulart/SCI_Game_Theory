if memory == None:
	memory = 0

if last_move == 1:
	memory = 1

if memory == 1:
	coop = 1
else:
	coop = 0