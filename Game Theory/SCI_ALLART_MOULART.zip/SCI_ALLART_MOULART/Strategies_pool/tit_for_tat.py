if last_move == None:
	coop = 1
else:
	coop = last_move