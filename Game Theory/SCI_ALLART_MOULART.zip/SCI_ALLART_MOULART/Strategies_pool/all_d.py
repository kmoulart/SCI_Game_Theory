if memory == None:
	memory = 1
coop = 0