if last_move == None:
	last_move = 0
	
coop = last_move